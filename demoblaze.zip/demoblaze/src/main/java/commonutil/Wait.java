package commonutil;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import managers.FileReaderManager;
import pageObjects.HomePage;
import pageObjects.PlaceOrderPage;


public class Wait {
	

	public static void switchToAlertWhenIsPresent(WebDriver driver) {
		  WebDriverWait wait = new WebDriverWait(driver, FileReaderManager.getInstance().getConfigReader().getImplicitlyWait());
		  wait.until(ExpectedConditions.alertIsPresent());
		  driver.switchTo().alert().accept();
	}

	
	public static void waitForAddTocart(WebDriver driver) {
		  WebDriverWait wait = new WebDriverWait(driver, FileReaderManager.getInstance().getConfigReader().getImplicitlyWait());
		  wait.until(ExpectedConditions.visibilityOf(HomePage.objAddTocart()));
	
	}
	
	public static void waitForHomePage(WebDriver driver) {
		  WebDriverWait wait = new WebDriverWait(driver, FileReaderManager.getInstance().getConfigReader().getImplicitlyWait());
		  wait.until(ExpectedConditions.visibilityOf(HomePage.objLaptop()));
	
	}
	
	public static void waitForPlaceOrder(WebDriver driver) {
		  WebDriverWait wait = new WebDriverWait(driver, FileReaderManager.getInstance().getConfigReader().getImplicitlyWait());
		  wait.until(ExpectedConditions.visibilityOf(PlaceOrderPage.objPlaceOrder()));
		
	}
	
	public static void waitForOkButton(WebDriver driver) {
		  WebDriverWait wait = new WebDriverWait(driver, FileReaderManager.getInstance().getConfigReader().getImplicitlyWait());
		  wait.until(ExpectedConditions.visibilityOf(PlaceOrderPage.objOk()));
		
	}
	
	public static void waitForDeletelink(WebDriver driver) {
		  WebDriverWait wait = new WebDriverWait(driver, FileReaderManager.getInstance().getConfigReader().getImplicitlyWait());
		  wait.until(ExpectedConditions.visibilityOf(PlaceOrderPage.objDelete()));
		
	}

	public static void waitForSpecificTime(long waitTime) throws InterruptedException {
		  Thread.sleep(waitTime);
	}
	
}