package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import managers.WebDriverManager;

public class PlaceOrderPage {
	WebDriverManager webDriverManager;
	WebDriver driver;
	public PlaceOrderPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	
	}
	
	@FindBy(how = How.ID, using = "name") 
	private WebElement txtbox_Name;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Home')]") 
	private WebElement link_Home;
	
	
	@FindBy(how = How.ID, using = "country") 
	private WebElement txtbox_Country;
	
	@FindBy(how = How.ID, using = "card") 
	private WebElement txtbox_Card;
	
	@FindBy(how = How.ID, using = "month") 
	private WebElement txtbox_Month;
	
	@FindBy(how = How.ID, using = "year") 
	private WebElement txtbox_Year;
	
	@FindBy(how = How.ID, using = "city") 
	private WebElement txtbox_City;
	
	@FindBy(how = How.ID, using = "totalp") 
	private WebElement txt_Total;
	
	@FindBy(how = How.CSS, using = "button.btn.btn-success") 
	private static WebElement btn_PlaceOrder;
	
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Purchase')]") 
	private WebElement btn_Purchase;
	
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'OK')]") 
	private static WebElement btn_OK;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Delete')]") 
	private static WebElement link_Delete;
	
	@FindBy(how = How.XPATH, using = "//div[@class='sweet-alert  showSweetAlert visible']") 
	private WebElement dialogtxt_userdetails;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbodyid']") 
	private WebElement webtable_product;
	
	public static WebElement objPlaceOrder() {
		return btn_PlaceOrder;
	}
	
	public static WebElement objDelete() {
		return link_Delete;
	}
	
	public static WebElement objOk() {
		return btn_OK;
	}
	
	public void clickOn_PlaceOrder() {
		btn_PlaceOrder.click();
	}
	

	public void clickOn_Purchase() {
		btn_Purchase.click();
	}
	
	
	public void clickOn_Ok() {
		btn_OK.click();
	}
	
	
	public void clickOn_Home() {
		link_Home.click();
	}
	
	public void enter_Name(String name) {
		txtbox_Name.sendKeys(name);
	}
	
	
	public void enter_Country(String country) {
		txtbox_Country.sendKeys(country);
	}
	
	public void enter_Card(String card) {
		txtbox_Card.sendKeys(card);
	}

	public void enter_Month(String month) {
		txtbox_Month.sendKeys(month);
	}
	
	public void enter_Year(String year) {
		txtbox_Year.sendKeys(year);
	}
	
	public void enter_City(String city) {
		txtbox_City.sendKeys(city);
	}
    
	
	public String get_userdetails( ) {
		return dialogtxt_userdetails.getText();
	}
	
	public String get_TotalAmount( ) {
		return txt_Total.getText();
	}
	
	public String get_purchaseID( ) {
		String details= get_userdetails();
		int indxeId=details.indexOf("Id:");
		int indxeAmount=details.indexOf("Amount:");
		String ID=details.substring(indxeId, indxeAmount);
		return ID;
	}
	
	public String get_Amount( ) {
		String details= get_userdetails();
		int indxeAmount=details.indexOf("Amount:");
		int indxeCardNumber=details.indexOf("Card Number:");
		String Amount=details.substring(indxeAmount, indxeCardNumber);
		return Amount;
	}
		
   public void deleteProductFromCart(String productname)
   {
	  List < WebElement > rows_table = webtable_product.findElements(By.tagName("tr"));
	  int rows_count = rows_table.size();
	  for (int row = 0; row < rows_count; row++) {
	   List < WebElement > Columns_row = rows_table.get(row).findElements(By.tagName("td"));
	   int columns_count = Columns_row.size();
	   for (int column = 0; column < columns_count; column++) {
	    String celltext = Columns_row.get(column).getText();
	    if (celltext.equals(productname))
	    {
	    	 row=row+1;
	    	 String var=driver.findElement(By.xpath("//*[@id='tbodyid']/tr[" + row + "]/td[4]/a")).getText();
	    	 if(var.equals("Delete"))
	    	 {
	    		 driver.findElement(By.xpath("//*[@id='tbodyid']/tr[" + row + "]/td[4]/a")).click();
	    		 break;
	    	 }	
	    }
	   }
	  }
   }
}