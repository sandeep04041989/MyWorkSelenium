package pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import dataProviders.ConfigFileReader;


public class HomePage {
	WebDriver driver;
	ConfigFileReader configFileReader;
	
	 
	public HomePage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
		configFileReader= new ConfigFileReader();
		
	}
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Laptops')]") 
	private static WebElement link_laptops;
	
	
	@FindBy(how = How.ID, using = "cartur") 
	private WebElement link_Cart;
	
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Dell i7 8gb')]") 
	private WebElement link_Dell;
	
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Sony vaio i5')]") 
	private WebElement link_Sony;
	

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Add to cart')]") 
	private static WebElement link_AddTocart;
	
	

	@FindBy(how = How.XPATH, using = "//h4[@class='card-title']") 
	private List<WebElement> link_AllLaptops;
	

	public static WebElement objAddTocart() {
		return link_AddTocart;
	}
	
	public static WebElement objLaptop() {
		return link_laptops;
	}
	
	public void navigateTo_HomePage() {
		driver.get(configFileReader.getApplicationUrl());
	}
	
	

	public void clickOn_Cart() {
		link_Cart.click();
	}
	
	
	public void clickOn_Laptops() {
		link_laptops.click();
	}
	
	public void clickOn_AddtoCart() {
		link_AddTocart.click();
	}
	
	public void selectLaptop(String laptopname) {
		for (WebElement Element : link_AllLaptops) {
			    System.out.println(Element.getText());	    
			    String var=Element.getText();   
			    if(var.equals(laptopname))
				{  	
			    	Element.click();
					break;
				}		    		    
		}
	}
	
}