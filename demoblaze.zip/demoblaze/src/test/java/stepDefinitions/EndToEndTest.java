package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import com.cucumber.listener.Reporter;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import managers.FileReaderManager;
import pageObjects.HomePage;
import pageObjects.PlaceOrderPage;
import commonutil.Wait;
import cucumber.TestContext;

public class EndToEndTest {

	 TestContext testContext;
	 HomePage homePage;
	 PlaceOrderPage placeOrderpage;
	 WebDriver driver;
	 String totalAmount;
	 
	
	 public EndToEndTest(TestContext context) {
		 testContext = context;
		 homePage = testContext.getPageObjectManager().getHomePage();
		 placeOrderpage=testContext.getPageObjectManager().getPlaceOrderPage();
		 driver=testContext.getWebDriverManager().getDriver();
		 }
		
		@Given("^user is on home Page$")
		public void user_is_on_home_Page() throws Throwable {
			 homePage.navigateTo_HomePage();
		}
		
		@When("^he Add first laptops  \"([^\"]*)\" by clicking on Add to cart$")
		public void he_Add_first_laptops_by_clicking_on_Add_to_cart(String arg1) throws Throwable {
			homePage.clickOn_Laptops();
			Wait.waitForSpecificTime(FileReaderManager.getInstance().getConfigReader().getSpecificWait());
			homePage.selectLaptop(arg1);
			Wait.waitForAddTocart(driver);
			homePage.clickOn_AddtoCart();
			Wait.switchToAlertWhenIsPresent(driver);
		}
		
		@When("^Navigate to Home Page for Second item$")
		public void navigate_to_Home_Page_for_Second_item() throws Throwable {
			placeOrderpage.clickOn_Home();
		}
		
		@When("^he Add Second laptops  \"([^\"]*)\" by clicking on Add to cart$")
		public void he_Add_Second_laptops_by_clicking_on_Add_to_cart(String arg1) throws Throwable {
			homePage.clickOn_Laptops();
			Wait.waitForSpecificTime(FileReaderManager.getInstance().getConfigReader().getSpecificWait());
			homePage.selectLaptop(arg1);
			Wait.waitForAddTocart(driver);
			homePage.clickOn_AddtoCart();
			Wait.switchToAlertWhenIsPresent(driver);
		}
		
		@When("^Navigate to Cart Page for Added item to delete \"([^\"]*)\" from cart$")
		public void navigate_to_Cart_Page_for_Added_item_to_delete_from_cart(String arg1) throws Throwable {
			 homePage.clickOn_Cart();
			 Wait.waitForPlaceOrder(driver);
			 placeOrderpage.deleteProductFromCart(arg1);
		}

		
		@When("^Place order for selected item$")
		public void place_order_for_selected_item() throws Throwable {
			Wait.waitForDeletelink(driver);
			Wait.waitForSpecificTime(FileReaderManager.getInstance().getConfigReader().getSpecificWait());
			totalAmount=placeOrderpage.get_TotalAmount();
			placeOrderpage.clickOn_PlaceOrder();
			placeOrderpage.enter_Card("card");
			placeOrderpage.enter_Name("name");
			placeOrderpage.enter_City("city");
			placeOrderpage.enter_Country("country");
			placeOrderpage.enter_Month("month");
			placeOrderpage.enter_Year("year");
			placeOrderpage.clickOn_Purchase();		
		}
		
		@Then("^verify the order details$")
		public void verify_the_order_details() throws Throwable {
			Wait.waitForOkButton(driver);
			Assert.assertTrue("purchase amount does not equals as expected Total amount is-->"+totalAmount + "and Purchase amount"+ placeOrderpage.get_Amount(), placeOrderpage.get_Amount().contains(totalAmount));
			Reporter.addStepLog("Total Amount"+placeOrderpage.get_Amount());
			Reporter.addStepLog("Purchase ID"+placeOrderpage.get_purchaseID());
			placeOrderpage.clickOn_Ok();	
		}
}
